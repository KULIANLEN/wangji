import json
import requests
from bs4 import BeautifulSoup
xheaders = {
    "user-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 Edg/116.0.1938.76"
}

i = 6872578


all = []
while(i <= 6872581):
    print(i)
    i += 1

    turl = "https://book.douban.com/subject/"
    xurl = turl+str(i)
    content = requests.get(url=xurl, headers=xheaders).text
    soup = BeautifulSoup(content, "html.parser")
    print(content)
    title = soup.find("h1")
    title = title.find("span")

    intro = soup.find("div", attrs={"class": "intro"})
    if intro == None:
        intro = "没有简介！"
    else:
        intro = intro.find("p")
    print(title)
    all.append({'titile': title.string, 'introduction': intro})

with open(r"douban.json", "w", encoding='utf-8') as xx:
    json.dump(all, xx, ensure_ascii=False, indent=4, sort_keys=True)
    print("ok")
