<template>
	<view class="superbox">
		<view >
			<image :src="convert(jieshou1)" style="width: 100vw;height: 50vw;" mode="aspectFill"></image>
		</view>
		
			<view class="text" style="font-size: 10vw;font-weight: bold;">{{shuzu[jieshou1].question}}
			</view>
		
		<view >
			<view class="text2">{{shuzu[jieshou1].answers[jieshou1].author}}</view>
		</view>
		<image class="image" src="../../images/th.jpg" mode=""></image>
		<view>
			<view class="text">{{shuzu[jieshou1].answers[jieshou1].answer_text}}</view>
		</view>
		

	</view>
</template>

<script>
	import text from './qa.json'
	export default {
		data() {
			return {
				shuzu: [],
				jieshou1: 0,
			}
		},
		onShow() {
			this.shuzu = text
			// console.log(this.shuzu)
			this.jieshou1 = this.$route.query.index;
			if (!this.jieshou1) this.jieshou1 = 0
			console.log(this.jieshou1)
			this.convert(this.jieshou1)

		},

		methods: {
			convert(index) {
				// index = Number(index)
				index = index%8+1
				console.log('../../images/lzu' + index + '.webp')
				return require('../../images/lzu' + index + '.webp')
			},
			
			
			



		}
	}
</script>

<style>
	.superbox {
		display: flex;
		flex-direction: column;
		
	}

	.text {
		margin: 1vw;
	}

	.text2 {
		margin: 1vw;
		color: #c2ccd0;
	}
	.image{
		width: 50vw;
height: 20vh;
	
	}
</style>