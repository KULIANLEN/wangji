var articles = [
{
	title : "让党旗在军训场上飘扬——三营八连临时党支部学习教育活动",
	author : "廖敏婧",
	src : "第二临床医学院",
	uid : 0,
	time : "2023-09-06",
	mode : 1,
	parts : [
		{
			v : "兰州大学2023级本科新生军训工作正在如火如荼地进行，由第二临床医学院与生态学院组建的三营八连，成立了临时党支部，选优配强支部党员，充分发挥党员先锋模范作用，开展一系列的思想政治教育和保障服务工作。",
			t : "p"
		},
		{
			v : "https://img.micosliang.space/cyonline/junxun/articles/0/1.jpg",
			t : "i"
		},
		{
			v : "https://img.micosliang.space/cyonline/junxun/articles/0/2.jpg",
			t : "i"
		},
		{
			v : "临时党支部建在军训场，后勤保障点设有保温桶、医疗箱等设施，随时保障军训学生的基本需求，并组织学生志愿者帮助生病的同学及时就医，解决他们的困难。支部以实际行动，强化了师生党员和参训学生的血肉联系，及时解决他们在军训中出现的问题，使得军训工作得以顺利进行。",
			t : "p"
		},
		{
			v : "https://img.micosliang.space/cyonline/junxun/articles/0/3.jpg",
			t : "i"
		},
		{
			v : "https://img.micosliang.space/cyonline/junxun/articles/0/4.jpg",
			t : "i"
		},
		{
			v : "9月6日，军训开始的第二天，三营八连临时党支部设立了理论学习点，党支部的老师们带领学生开展政治理论学习教育，配备了《让信仰点亮人生》《中国共产党简史》等理论书籍，以及发展党员相关资料，供同学们在军训休息时借阅学习。",
			t : "p"
		},
		{
			v : "https://img.micosliang.space/cyonline/junxun/articles/0/5.jpg",
			t : "i"
		},
		{
			v : "党支部郭文君老师为同学们讲解了党的基本知识，强调要端正入党动机，明确入党程序，提高了同学们的党性修养，激发了更多学生向党组织靠拢的决心。",
			t : "p"
		},
		{
			v : "https://img.micosliang.space/cyonline/junxun/articles/0/6.jpg",
			t : "i"
		},
		{
			v : "军训团副政委党宪老师向同学们讲述自己曾经的求学、工作经历，与同学们交流军训的重要意义，并鼓励同学们在军训中克服困难，坚持训练，培养自己吃苦耐劳的精神。",
			t : "p"
		},
		{
			v : "https://img.micosliang.space/cyonline/junxun/articles/0/7.jpg",
			t : "i"
		},
		{
			v : "在三营八连临时党支部营造的浓厚学习氛围中，同学们在军训场上撰写了三营八连第一批入党申请书，党支部的学习教育活动润物无声地发挥了军训育人成效。",
			t : "p"
		},
		{
			v : "https://img.micosliang.space/cyonline/junxun/articles/0/8.jpg",
			t : "i"
		},
		{
			v : "https://img.micosliang.space/cyonline/junxun/articles/0/9.jpg",
			t : "i"
		},
		{
			v : "下一步，临时党支部将继续发挥引领作用，在习近平新时代中国特色社会主义思想的指导下，落实学校对军训的各项要求，陪伴同学们度过丰富而充实的军训生活。",
			t : "p"
		}
	]
},
]