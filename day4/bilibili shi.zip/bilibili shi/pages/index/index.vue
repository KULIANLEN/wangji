<template>

	<view class='bigbox'>
		<view class="topbox"><!-- //顶部图片滑动 -->
			<swiper circular indicator-dots autoplay interval=5000>
				<swiper-item mode="aspectFill">
					<image src="../../images/lzu1.webp"></image>
				</swiper-item>

				<swiper-item>
					<image src="../../images/lzu7.webp" mode=""></image>
				</swiper-item>

				<swiper-item>
					<image src="../../images/lzu2.webp" mode=""></image>

				</swiper-item>
			</swiper>


		</view>
		<view class="item"  @click="click(index)" v-for="(item,index) in question" :key="index">

			<image :src="convert(index)" style="width: 100%;height: 50%;" mode="aspectFill"></image>
			<view style="font-size: 4vw">{{item.answers[0].answer_text.substring(0,32)+'...'}}</view>
			<view style="color:#c2ccd0;font-size: 1vh;">{{item.answers[0].author}}</view>

		</view>
		<view style="height: 10vh; width: 100vw;"></view>
		<view>
			<!-- <view class=smallbox>
				<image v-if="jieshou==1" @click="shuchu(1)" class=bottombox src="../../images/onclick.png" mode="">
				</image>
				<image v-else @click="shuchu(1)" class=bottombox src="../../images/shouye.png" mode=""></image>
			</view>

			<view class="smallbox">

				<image v-if="jieshou==2" @click="shuchu(2)" class=bottombox src="../../images/onclick.png" mode="">
				</image>
				<image v-else @click="shuchu(2)" class=bottombox src="../../images/shouye.png" mode=""></image>
			</view>
			<view class=smallbox>
				<image  v-if="jieshou==3" @click="shuchu(3)" class="bottombox" src="../../images/onclick.png" mode=""></image>
				<image v-else @click="shuchu(3)" class="bottombox" src="../../images/shouye.png" mode=""></image>
			</view> -->
			<view class="tabbar">
				<view class="row-container">
					<image v-if="jieshou==1" class="icon" @click="shuchu(1)" src="../../images/onclick.png"></image>
					<image v-else class="icon" @click="shuchu(1)" src="../../images/shouye.png">

					</image>
					<text class="text-area">首页1</text>
				</view>

				<view class="row-container">
					<image v-if="jieshou==2" class="icon" @click="shuchu(2)" src="../../images/onclick.png"></image>
					<image v-else class="icon" @click="shuchu(2)" src="../../images/shouye.png"></image>
					<text class="text-area">首页2</text>
				</view>

				<view class="row-container">
					<image v-if="jieshou==3" class="icon" @click="shuchu(3)" src="../../images/onclick.png"></image>
					<image v-else class="icon" @click="shuchu(3)" src="../../images/shouye.png"></image>
					<text class="text-area">首页3</text>
				</view>
			</view>

		</view>

	</view>
</template>

<script>
	import questionAndAnswers from './qa.json'
	export default {
		data() {
			return {
				question: [],
				jieshou: 0,
			}
		},
		onLoad() {
			console.log(questionAndAnswers)
			this.question = questionAndAnswers
		},
		methods: {
			convert(index) {
				let tmp = Number(index)
				tmp += 1
				if (tmp > 8) tmp = tmp - 6
				return require('../../images/lzu' + tmp + '.webp')

			},
			shuchu(shou) {
				console.log(shou)
				this.jieshou = shou
			},
			click(index) {
				// console.log(index, index),
					uni.navigateTo({
						url: '/pages/index/open?index=' + index,
					});
			}


		}
	}
</script>

<style>
	.topbox {
		width: 100vw;
		height: 25vh;
		margin-bottom: 8vh;
		margin-top: 1vh;
	}

	.tabbar {
		display: flex;
		justify-content: space-around;
		height: 10vh;
		width: 100vw;
		background-color: #758a99;
		position: fixed;
		bottom: 0;


	}

	.row-container {
		display: flex;
		flex-direction: column;
		justify-content: center;

	}

	.icon {
		display: flex;
		width: 10vw;
		height: 10vw;
	}

	.images {
		width: 5vw;
		height: 5vh;
	}

	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: space-between;
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: space-between;
		font-size: 0.5vh;
	}

	.title {
		font-size: 36rpx;
		color: #8f8f94;

	}

	.item {
		display: flex;
		flex-direction: column;
		background-color: #ffffff;

		width: 45vw;
		height: 27vh;
		margin: 1vw;
		box-shadow: rgba(255, 255, 255, 0.1) 0px 1px 1px 0px inset, rgba(50, 50, 93, 0.25) 0px 50px 100px -20px, rgba(0, 0, 0, 0.3) 0px 30px 60px -30px;




	}

	.bigbox {
		display: flex;
		/* flex-direction: column; */
		flex-wrap: wrap;
		justify-content: space-between;
		width: 95vw;
		height: 90vh;
		/* height: 500px; */
		padding: 1vw;
		padding-bottom: 10vh;

	}

	.smallbox {
		display: flex;
		position: fixed;
		bottom: 0;
		justify-content: space-around;
		align-items: center;
		width: 100vw;
		height: 10vh;

		background: rgba(255, 105, 180, 0.9)
	}

	.bottombox {
		width: 10vw;
		height: 5vh;
		display: flex;
	}
</style>